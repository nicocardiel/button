/*---------------------------------------------------------------------------*/
/* Version 24-February-1999                                File: cifbutton.c */
/*---------------------------------------------------------------------------*/
/* Copyright N. Cardiel & C.E. Garcia, Departamento de Astrofisica           */
/* Universidad Complutense de Madrid, 28040-Madrid, Spain                    */
/* E-mail: ncl@astrax.fis.ucm.es or ceg@astrax.fis.ucm.es                    */
/*---------------------------------------------------------------------------*/
/* This routine is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the Free*/
/* Software Foundation; either version 2 of the License, or (at your option) */
/* any later version. See the file gnu-public-license.txt for details.       */
/*---------------------------------------------------------------------------*/
/*Comment                                                                    */
/*                                                                           */
/* void cifbutton(float xc,float yc,int *nb)                                 */
/*                                                                           */
/* input: xc,yc                                                              */
/* output: nb                                                                */
/*                                                                           */
/* Determine whether any button has been selected.                           */
/*                                                                           */
/* float xc -> world x-coordinate of the cursor                              */
/* float yc -> world y-coordinate of the cursor                              */
/* int nb -> number of the selected button (if available); this number       */
/*           returns zero if no button has been selected                     */
/*                                                                           */
/*Comment                                                                    */
/*---------------------------------------------------------------------------*/
#include "cpgplot.h"
#include "cownbutton.h"

void cifbutton(float xc,float yc,int *nb)
{
  /* variables locales */
  int i;
  int nlin,ncol;
  float x1w,x2w,y1w,y2w;
  float x1v,x2v,y1v,y2v;
  float escx,escy;
  float dx,dy;
  float x1,x2,y1,y2;
  float nx1,nx2,ny1,ny2;
  float xx1,xx2,yy1,yy2;

  cpgqwin(&x1w,&x2w,&y1w,&y2w);
  cpgqvp(0,&x1v,&x2v,&y1v,&y2v);
  escx=(x2w-x1w)/(x2v-x1v);
  escy=(y2w-y1w)/(y2v-y1v);

  dx=x4vport-x3vport;
  dy=y4vport-y3vport;

  for(i=0; i<max_xbutt*max_ybutt;i++)
    {
    if(exist_butt[i])
      {
      nlin=(i+1-1)/max_xbutt+1;
      ncol=(i+1)-(nlin-1)*max_xbutt;
      x1=x3vport+((float)(ncol-1))*dx/((float)max_xbutt);
      x2=x1+dx/((float)max_xbutt);
      y2=y4vport-((float)(nlin-1))*dy/((float)max_ybutt);
      y1=y2-dy/((float)max_ybutt);
      nx1=x1w+(x1-x1v)*escx;
      nx2=x1w+(x2-x1v)*escx;
      ny1=y1w+(y1-y1v)*escy;
      ny2=y1w+(y2-y1v)*escy;
      if(nx1 < nx2)
        {
        xx1=nx1;
        xx2=nx2;
        }
      else
        {
        xx1=nx2;
        xx2=nx1;
        }
      if(ny1 < ny2)
        {
        yy1=ny1;
        yy2=ny2;
        }
      else
        {
        yy1=ny2;
        yy2=ny1;
        }
      if((xx1 <= xc) && (xx2 >= xc) && (yy1 <= yc) && (yy2 >= yc))
        {
        *nb=i+1;
        return;
        }
      }
    }
    *nb=0;
}
