/*---------------------------------------------------------------------------*/
/* Version 24-February-1999                                  File: rcpgenv.c */
/*---------------------------------------------------------------------------*/
/* Copyright N. Cardiel & C.E. Garcia, Departamento de Astrofisica           */
/* Universidad Complutense de Madrid, 28040-Madrid, Spain                    */
/* E-mail: ncl@astrax.fis.ucm.es or ceg@astrax.fis.ucm.es                    */
/*---------------------------------------------------------------------------*/
/* This routine is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the Free*/
/* Software Foundation; either version 2 of the License, or (at your option) */
/* any later version. See the file gnu-public-license.txt for details.       */
/*---------------------------------------------------------------------------*/
/*Comment                                                                    */
/*                                                                           */
/* void rcpgenv(float xmin,float xmax,float ymin,float ymax,int just,        */
/*              int axis)                                                    */
/*                                                                           */
/* input: xmin,xmax,ymin,ymax,just,axis                                      */
/*                                                                           */
/* Perform the same functions than cpgenv, although the plot surface is      */
/* restricted to the rectangle defined by x1vport,x2vport,y1vport,y2vport.   */
/* Other important difference with cpgenv is that rcpgenv does not clear the */
/* plot region of the new plot. A previous call to cpgadvance, cpgpage,      */
/* cpgeras (rcpgadvance, rcpgpage, rcpgeras) is required. The arguments of   */
/* this routine are exactly the same than those in cpgenv:                   */
/*                                                                           */
/* float xmin -> the world x-coordinate at the bottom left corner of the     */
/*               viewport                                                    */
/* float xmax -> the world x-coordinate at the top right corner of the       */
/*               viewport                                                    */
/* float ymin -> the world y-coordinate at the bottom left corner of the     */
/*               viewport                                                    */
/* float ymax -> the world y-coordinate at the top right corner of the       */
/*               viewport                                                    */
/* int just   -> if just=1, the scales of the x and y axes (in world         */
/*               coordinates per inch) will be equal, otherwise they will be */
/*               scale independently                                         */
/* int axis   -> controls the plotting of the axis, tick marks, etc:         */
/*               axis=-2: draw no box, axes or labels                        */
/*               axis=-1: draw box only                                      */
/*               axis= 0: draw box and label it with coordinates             */
/*               axis= 1: same as axis=0, but also draw the coordinate axes  */
/*               axis= 2: same as axis=1, but also draw grid lines           */
/*               axis=10: draw box and label X-axis logarithmically          */
/*               axis=20: draw box and label Y-axis logarithmically          */
/*               axis=30: draw box and label both axes logarithmically       */
/*                                                                           */
/*Comment                                                                    */
/*---------------------------------------------------------------------------*/
#include "cpgplot.h"
#include "cownbutton.h"

void rcpgenv(float xmin,float xmax,float ymin,float ymax,int just,int axis)
{
  /* variables locales */
  char xopts[15],yopts[15];

  if ((modotext_butt) && (! modotext_plotbutt))
    {
    cpgenv(xmin,xmax,ymin,ymax,just,axis);
    return;
    }

  cpgsvp(x1vport,x2vport,y1vport,y2vport);
  if(xmin == xmax)
    {
    printf("invalid x limits in rcpgenv: XMIN=XMAX.\n");
    return;
    }
  if(ymin == ymax)
    {
    printf("invalid y limits in rcpgenv: YMIN=YMAX.\n");
    return;
    }

  if(just == 1)
    cpgwnad(xmin,xmax,ymin,ymax);
  else
    cpgswin(xmin,xmax,ymin,ymax);

  strcpy(yopts,"*");
  if(axis == -2)
    strcpy(xopts," ");
  else if(axis == -1)
    strcpy(xopts,"BC");
  else if(axis == 0)
    strcpy(xopts,"BCNST");
  else if(axis == 1)
    strcpy(xopts,"ABCNST");
  else if(axis == 2)
    strcpy(xopts,"ABCGNST");
  else if(axis == 10)
    {
    strcpy(xopts,"BCNSTL");
    strcpy(yopts,"BCNST");
    }
  else if(axis == 20)
    {
    strcpy(xopts,"BCNST");
    strcpy(yopts,"BCNSTL");
    }
  else if(axis == 30)
    {
    strcpy(xopts,"BCNSTL");
    strcpy(yopts,"BCNSTL");
    }
  else
    {
    printf("rcpgenv: illegal axis argument.\n");
    strcpy(xopts,"BCNST");
    }

  if (strcmp(yopts,"*") == 0)
    strcpy(yopts,xopts);

  /* invert tick marks if necessary */
  if(iticks_butt)
    {
    strcat(xopts,"I");
    strcat(yopts,"I");
    }

  /* draw box */
  cpgbox(xopts,0.0,0,yopts,0.0,0);

  return;
}
