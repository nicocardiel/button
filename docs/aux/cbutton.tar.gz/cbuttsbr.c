/*---------------------------------------------------------------------------*/
/* Version 25-February-1999                                 File: cbuttsbr.c */
/*---------------------------------------------------------------------------*/
/* Copyright N. Cardiel & C.E. Garcia, Departamento de Astrofisica           */
/* Universidad Complutense de Madrid, 28040-Madrid, Spain                    */
/* E-mail: ncl@astrax.fis.ucm.es or ceg@astrax.fis.ucm.es                    */
/*---------------------------------------------------------------------------*/
/* This routine is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the Free*/
/* Software Foundation; either version 2 of the License, or (at your option) */
/* any later version. See the file gnu-public-license.txt for details.       */
/*---------------------------------------------------------------------------*/
/*Comment                                                                    */
/*                                                                           */
/* void cbuttsbr(float x1,float x2,float y1,float y2)                        */
/*                                                                           */
/* input: x1,x2,y1,y2                                                        */
/*                                                                           */
/* Set the button region limits.                                             */
/*                                                                           */
/* float x1 -> x-coordinate of the left hand edge of the button region       */
/*             viewport, in normalized device coordinates                    */
/* float x2 -> x-coordinate of the right hand edge of the button region      */
/*             viewport, in normalized device coordinates                    */
/* float y1 -> y-coordinate of the bottom edge of the button region          */
/*             viewport, in normalized device coordinates                    */
/* float y2 -> x-coordinate of the top edge of the button region             */
/*             viewport, in normalized device coordinates                    */
/*                                                                           */
/*Comment                                                                    */
/*---------------------------------------------------------------------------*/
#include "cownbutton.h"

void cbuttsbr(float x1,float x2,float y1,float y2)
{
  x3vport=x1;
  x4vport=x2;
  y3vport=y1;
  y4vport=y2;
}
