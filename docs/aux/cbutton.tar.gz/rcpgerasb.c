/*---------------------------------------------------------------------------*/
/* Version 25-February-1999                                File: rcpgerasb.c */
/*---------------------------------------------------------------------------*/
/* Copyright N. Cardiel & C.E. Garcia, Departamento de Astrofisica           */
/* Universidad Complutense de Madrid, 28040-Madrid, Spain                    */
/* E-mail: ncl@astrax.fis.ucm.es or ceg@astrax.fis.ucm.es                    */
/*---------------------------------------------------------------------------*/
/* This routine is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the Free*/
/* Software Foundation; either version 2 of the License, or (at your option) */
/* any later version. See the file gnu-public-license.txt for details.       */
/*---------------------------------------------------------------------------*/
/*Comment                                                                    */
/*                                                                           */
/* void rcpgerasb()                                                          */
/*                                                                           */
/* Clear the button region (preserving the plot region which does not        */
/* overlap with the button region)                                           */
/*                                                                           */
/*Comment                                                                    */
/*---------------------------------------------------------------------------*/
#include "cpgplot.h"
#include "cownbutton.h"

void rcpgerasb()
{
  /* variables locales */
  int ci,fs;
  float x1w,x2w,y1w,y2w;
  float x1v,x2v,y1v,y2v;

  cpgqwin(&x1w,&x2w,&y1w,&y2w);
  cpgqvp(0,&x1v,&x2v,&y1v,&y2v);

  cpgsvp(x3vport,x4vport,y3vport,y4vport);
  cpgswin(0.0,1.0,0.0,1.0);
  cpgqci(&ci);
  cpgqfs(&fs);
  cpgsci(0);
  cpgsfs(1);
  cpgrect(0.0,1.0,0.0,1.0);
  cpgsci(ci);
  cpgsfs(fs);

  cpgsvp(x1v,x2v,y1v,y2v);
  cpgswin(x1w,x2w,y1w,y2w);
}
