/*---------------------------------------------------------------------------*/
/* Version 23-February-1999                                File: rcpgbegok.c */
/*---------------------------------------------------------------------------*/
/* Copyright N. Cardiel & C.E. Garcia, Departamento de Astrofisica           */
/* Universidad Complutense de Madrid, 28040-Madrid, Spain                    */
/* E-mail: ncl@astrax.fis.ucm.es or ceg@astrax.fis.ucm.es                    */
/*---------------------------------------------------------------------------*/
/* This routine is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the Free*/
/* Software Foundation; either version 2 of the License, or (at your option) */
/* any later version. See the file gnu-public-license.txt for details.       */
/*---------------------------------------------------------------------------*/
/*Comment                                                                    */
/*                                                                           */
/* void rcpgbegok(char tter[],imode)                                         */
/*                                                                           */
/* input: tter,imode                                                         */
/* output: all global variables in cbutton.h                                 */
/*                                                                           */
/* Open the graphic device tter and assign the default values to the global  */
/* variables.                                                                */
/*                                                                           */
/*  max_xbutt=6                                                              */
/*  max_ybutt=2                                                              */
/*  pgscf_butt=2                                                             */
/*  pgsch_butt=1.0                                                           */
/*  ytext_butt=0.35                                                          */
/*  x1vport=0.10                                                             */
/*  x2vport=0.95                                                             */
/*  y1vport=0.10                                                             */
/*  y2vport=0.70                                                             */
/*  x3vport=0.05                                                             */
/*  x4vport=0.95                                                             */
/*  y3vport=0.80                                                             */
/*  y4vport=0.95                                                             */
/*                                                                           */
/* char tter[] -> graphic device to be opened                                */
/* int imode -> define the mode to operate with the buttons:                 */
/*              imode = 0: graphics buttons                                  */
/*              imode = 1: text buttons (but plot graphic buttons)           */
/*              imode = 2: text buttons (without graphic buttons)            */
/*                                                                           */
/*Comment                                                                    */
/*---------------------------------------------------------------------------*/
#include "cpgplot.h"
#include "cownbutton.h"

void rcpgbegok(char tter[],int imode)
{
  int i;
  char cdummy;

  cpgbeg(0,tter,1,1);                            /*abrimos la salida grafica */
  cpgask(1);
  max_xbutt=6;             /* definimos las variables de entorno por defecto */
  max_ybutt=2;
  pgscf_butt=2;
  pgsch_butt=1.0;
  ytext_butt=0.35;
  x1vport=0.10;
  x2vport=0.95;
  y1vport=0.10;
  y2vport=0.70;
  x3vport=0.05;
  x4vport=0.95;
  y3vport=0.80;
  y4vport=0.95;
  for (i=0; i < MAX_NBUTT; i++)     /* ningun boton ha sido dibujado todavia */
    exist_butt[i]= 0;
  iticks_butt=0;                       /* los ticks se dibujan hacia adentro */
  /* redefinimos colores */
  cpgscr(12,0.5,0.5,0.5);                                 /* gris intermedio */
  cpgscr(13,0.7,0.7,0.7);                                      /* gris claro */
  cpgscr(14,0.3,0.3,0.3);                                     /* gris oscuro */
  cpgscr(15,0.6,0.6,0.6);                            /* casi gris intermedio */
 /* definimos el modo de trabajar con los botones */
  if(imode == 0)
    {
    modotext_butt=0;
    modotext_plotbutt=0;
    }
  else if(imode == 1)
    {
    modotext_butt=1;
    modotext_plotbutt=1;
    }
  else if(imode == 2)
    {
    modotext_butt=1;
    modotext_plotbutt=0;
    }
  else
    {
    printf("ERROR Invalid imode in subroutine rcpgbegok:\n");
    printf(">>> imode = %d (imode = 0 will be assumed)\n",imode);
    modotext_butt=0;
    modotext_plotbutt=0;
    }
  return;
}
