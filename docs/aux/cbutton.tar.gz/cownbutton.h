/*---------------------------------------------------------------------------*/
/* Version 23-February-1999                               File: cownbutton.h */
/*---------------------------------------------------------------------------*/
#define MAX_NBUTT 1000 /* maximum number of buttons */
#define MAX_ID_BUTT 8  /* maximum number of graphic devices that can be
                          employed simultaneously */
int max_xbutt;         /* maximum number of columns */
int max_ybutt;         /* maximum number of rows */
int pgscf_butt;        /* character font in buttons */
float pgsch_butt;      /* font size in buttons */
float ytext_butt;      /* relative position of the text baseline in buttons */
float x1vport;         /* plot region.... */
float x2vport;         /* ............... */
float y1vport;         /* ............... */
float y2vport;         /* ............... */
float x3vport;         /* button region.. */
float x4vport;         /* ............... */
float y3vport;         /* ............... */
float y4vport;         /* ............... */
int exist_butt[MAX_NBUTT]; /* determines whether the button exist or not */
int iticks_butt;       /* if true tick marks are drawn outside the viewport 
                         instead of inside */
int modotext_butt;     /* if true buttons appear in text mode */
int modotext_plotbutt; /* buttons appear in text mode but they are also 
                          plotted */
/*-----------------------------------------------------------------------------
Miscellany (RESTOS DEL FORTRAN)
	INTEGER TBEGBUTT,TLENBUTT
	INTEGER READIBUTT
	REAL READFBUTT
	CHARACTER*255 READCBUTT
-----------------------------------------------------------------------------*/
