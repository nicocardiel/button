/*-----------------------------------------------------------------------------
Para compilar:
% g77 -o sample sample.c ../libcbutton.a -L$PGPLOT_DIR -lcpgplot -lpgplot 
      /usr/X11/lib/libX11.a

Nota: cambiar de orden "-lcpgplot" y "-lpgplot" impide compilar el programa
-----------------------------------------------------------------------------*/
#include <math.h>
#include <stdio.h>
#include "cpgplot.h"
#include "cbutton.h"

main()
{
  /* variables locales */
  int lexit;
  int nb;
  int i;
  int ncolor;
  float xc,yc;
  float xx[100],yy[100];
  float xv3,xv4,yv3,yv4;
  char ch,cdummy;

  /* abrimos la salida grafica */
  rcpgbegok("/xserve",0);

  /* dibujamos los botones */
  cbutton(1,"sin",0);
  cbutton(2,"cos",0);
  cbutton(3,"clear",0);
  cbutton(4,"color",0);
  cbutton(6,"EXIT",0);
  cbutton(7,"mode 0",0);
  cbutton(8,"mode 1",0);
  cbutton(8,"mode 1",1);
  cbutton(9,"mode 2",0);
  cbutton(10,"mode 3",0);
  cbutton(10,"mode 3",3);
  cbutton(11,"mode 4",4);
  cbutton(12,"mode 5",5);

  ncolor=1;

  rcpgenv(0.,1.,-1.1,1.1,0,0);
  cpglab("X axis","Y axis","Plot label");

  lexit=0;
  while (!lexit)
    {
    cpgband(0,0,0.,0.,&xc,&yc,&ch);
    cifbutton(xc,yc,&nb);
    printf("Numero de boton=%d.\n",nb);

    if(nb == 0)
      {
      printf("Cursor at X=%f, Y=%f\n",xc,yc);
      }
    else if(nb == 1)
      {
      cbutton(1,"sin",5);
      for(i=0;i<100;i++)
        {
        xx[i]=((float)i)/100.*2.*3.141593;
        yy[i]=sin(xx[i]);
        xx[i]=xx[i]/(2.*3.141593);
        }
      cpgsci(ncolor);
      cpgline(100,xx,yy);
      cpgsci(1);
      cbutton(1,"sin",0);
      }
    else if(nb == 2)
      {
      cbutton(2,"cos",5);
      for(i=0;i<100;i++)
        {
        xx[i]=((float)i)/100.*2.*3.141593;
        yy[i]=cos(xx[i]);
        xx[i]=xx[i]/(2.*3.141593);
        }
      cpgsci(ncolor);
      cpgline(100,xx,yy);
      cpgsci(1);
      cbutton(2,"cos",0);
      }
    else if(nb == 3)
      {
      cbutton(3,"clear",5);
      cbuttqbr(&xv3,&xv4,&yv3,&yv4);
      rcpgerasw(0.,1.,0.,yv3);
      rcpgenv(0.,1.,-1.1,1.1,0,0);
      cpglab("X axis","Y axis","Plot label");
      cbutton(3,"clear",0);
      }
    else if(nb == 4)
      {
      cbutton(4,"color",5);
      printf("Current PGPLOT color is number:%d.\n",ncolor);
      printf("New PGPLOT color number? ",&ncolor);
      scanf("%d",&ncolor);
      cbutton(4,"color",0);
      }
    else if(nb == 6)
      {
      cbutton(6,"EXIT",5);
      printf("press <CR> to exit...");
      setvbuf(stdin,"",_IOLBF,0);
      cdummy=getchar();
      lexit=1;
      cbutton(6,"EXIT",0);
      }
    }

  /* fin del programa */
  cpgend();
}
