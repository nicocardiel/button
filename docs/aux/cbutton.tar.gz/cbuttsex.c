/*---------------------------------------------------------------------------*/
/* Version 25-February-1999                                 File: cbuttsex.c */
/*---------------------------------------------------------------------------*/
/* Copyright N. Cardiel & C.E. Garcia, Departamento de Astrofisica           */
/* Universidad Complutense de Madrid, 28040-Madrid, Spain                    */
/* E-mail: ncl@astrax.fis.ucm.es or ceg@astrax.fis.ucm.es                    */
/*---------------------------------------------------------------------------*/
/* This routine is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the Free*/
/* Software Foundation; either version 2 of the License, or (at your option) */
/* any later version. See the file gnu-public-license.txt for details.       */
/*---------------------------------------------------------------------------*/
/*Comment                                                                    */
/*                                                                           */
/* void cbuttsex(int nb,int lexist)                                          */
/*                                                                           */
/* input: nb,lexist                                                          */
/*                                                                           */
/* Set whether the asked button is active (currently available) or not.      */
/*                                                                           */
/* int nb -> button number                                                   */
/* int lexist -> true to activate the button, false otherwise                */
/*                                                                           */
/*Comment                                                                    */
/*---------------------------------------------------------------------------*/
#include "cownbutton.h"

void cbuttsex(int nb,int lexist)
{
  if((nb < 1) || (nb > MAX_NBUTT))
    return;
  else
    exist_butt[nb-1]=lexist;
}
