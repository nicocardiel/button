/*---------------------------------------------------------------------------*/
/* Version 24-February-1999                                  File: cbutton.c */
/*---------------------------------------------------------------------------*/
/* Copyright N. Cardiel & C.E. Garcia, Departamento de Astrofisica           */
/* Universidad Complutense de Madrid, 28040-Madrid, Spain                    */
/* E-mail: ncl@astrax.fis.ucm.es or ceg@astrax.fis.ucm.es                    */
/*---------------------------------------------------------------------------*/
/* This routine is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the Free*/
/* Software Foundation; either version 2 of the License, or (at your option) */
/* any later version. See the file gnu-public-license.txt for details.       */
/*---------------------------------------------------------------------------*/
/*Comment                                                                    */
/*                                                                           */
/* void cbutton(int n,char text[],int mode)                                  */
/*                                                                           */
/* input: n,text,mode                                                        */
/*                                                                           */
/* Plot buttons and button text in different modes.                          */
/*                                                                           */
/* int n -> button number in the range of available buttons (which runs from */
/*          1 to MAX_XBUTT * MAX_YBUTT)                                      */
/* char text[] -> the text that will appear in the button                    */
/* int mode -> determine the button mode:                                    */
/*             mode=-2,-3,...: only text is plotted with PGPLOT              */
/*                  color=-NMODE-1 (i.e. 1,2,3....)                          */
/*             mode=-1 erase button                                          */
/*             mode=0 whole button is plotted (text in black)                */
/*             mode=1 only text is plotted (white)                           */
/*             mode=2 only text is plotted (black)                           */
/*             mode=3 only text is plotted (gray, button disabled)           */
/*             mode=4 whole button with reversed colors (text in black)      */
/*             mode=5 whole button with reversed colors (text in white)      */
/*                                                                           */
/*Comment                                                                    */
/*---------------------------------------------------------------------------*/
#include "cpgplot.h"
#include "cownbutton.h"

void cbutton(int n,char text[],int mode)
{
  /* funciones locales */
  void subdata(float xx[],float x1,float x2, float x3, float x4);
  /* variables locales */
  int lmode;
  int ncolortext;
  int nlin,ncol;
  int pgscf_old;
  float dx,dy;
  float x1,x2,y1,y2;
  float ddx,ddy;
  float xgap,ygap,offy;
  float x1w,x2w,y1w,y2w;
  float x1v,x2v,y1v,y2v;
  float pgsch_old;
  float xp[4],yp[4];

  /* algunas protecciones */
  lmode=mode;
  ncolortext=0;
  if((n > max_xbutt*max_ybutt) || (n < 1))
    {
    printf("ERROR: invalid button number in subroutine cbutton:\n");
    printf(">>> button number=%d.\n",n);
    return;
    }
  if(lmode > 5)
    {
    printf("ERROR: invalid button type in subroutine cbutton:\n");
    printf(">>> button type=%d.\n",lmode);
    return;
    }
  if(lmode < -1)
    {
    ncolortext=-lmode-1;
    lmode=2;
    }
  /* posicion del boton */
  nlin=(n-1)/max_xbutt+1;
  ncol=n-(nlin-1)*max_xbutt;
  if(lmode == -1)
    exist_butt[n-1]=0;
  else if(lmode == 3)
    exist_butt[n-1]=0;
  else
    exist_butt[n-1]=1;

  /* botones en modo grafico */
  if(((modotext_butt) && (modotext_plotbutt)) || (!modotext_butt))
    {
    dx=x4vport-x3vport;
    dy=y4vport-y3vport;

    x1=x3vport+((float)(ncol-1))*dx/((float)max_xbutt);
    x2=x1+dx/((float)max_xbutt);
    y2=y4vport-((float)(nlin-1))*dy/((float)max_ybutt);
    y1=y2-dy/((float)max_ybutt);

    ddx=(x2-x1)/20.;
    ddy=(y2-y1)/7.;
    xgap=ddx/10.;
    ygap=ddy/10.;
    offy=(y2-y1)*ytext_butt;
    
    x1=x1+xgap;
    x2=x2-xgap;
    y1=y1+ygap;
    y2=y2-ygap;

    cpgqwin(&x1w,&x2w,&y1w,&y2w);
    cpgqvp(0,&x1v,&x2v,&y1v,&y2v);
    cpgsvp(x3vport,x4vport,y3vport,y4vport);
    cpgswin(x3vport,x4vport,y3vport,y4vport);

    if(lmode == -1)
      {
      cpgsci(0);
      cpgrect(x1-xgap,x2+xgap,y1-ygap,y2+ygap);
      cpgsci(1);
      }
    else
      {
      cpgqcf(&pgscf_old);
      cpgscf(pgscf_butt);
      cpgqch(&pgsch_old);
      cpgsch(pgsch_butt);
      if((lmode >= 1) && (lmode <= 3))
        {
	if(lmode == 1)
	  {
	  cpgsci(1);
	  }
	else if(lmode == 2)
	  {
	  cpgsci(ncolortext);
	  }
	else if(lmode == 3)
	  {
	  exist_butt[n-1]=0;
	  cpgsci(15);
	  }
	cpgptxt((x1+x2)/2,y1+offy,0,0.5,text);
	}
      else
        {
	cpgsci(12);
	cpgrect(x1+ddx,x2-ddx,y1+ddy,y2-ddy);
	if(lmode == 0)
	  cpgsci(13);
	else
	  cpgsci(14);
	subdata(xp,x1,x1+ddx,x1+ddx,x1);
	subdata(yp,y1,y1+ddy,y2-ddy,y2);
	cpgpoly(4,xp,yp);
	subdata(xp,x1,x1+ddx,x2-ddx,x2);
	subdata(yp,y2,y2-ddy,y2-ddy,y2);
	cpgpoly(4,xp,yp);
	if(lmode==0)
	  cpgsci(14);
	else
	  cpgsci(13);
	subdata(xp,x1,x1+ddx,x2-ddx,x2);
	subdata(yp,y1,y1+ddy,y1+ddy,y1);
	cpgpoly(4,xp,yp);
	subdata(xp,x2,x2-ddx,x2-ddx,x2);
	subdata(yp,y1,y1+ddy,y2-ddy,y2);
	cpgpoly(4,xp,yp);
	if(lmode==0)
	  cpgsci(1);
	else
	  cpgsci(0);
	cpgmove(x1,y2);
	cpgdraw(x1+ddx,y2-ddy);
	if(lmode==0)
	  cpgsci(0);
	else
	  cpgsci(1);
	cpgmove(x2,y1);
	cpgdraw(x2-ddx,y1+ddy);
	if(lmode==5)
	  cpgsci(1);
	else
	  cpgsci(0);
	cpgptxt((x1+x2)/2,y1+offy,0,0.5,text);
	cpgsci(0);
	cpgmove(x1,y1);
	cpgdraw(x2,y1);
	cpgdraw(x2,y2);
	cpgdraw(x1,y2);
	cpgdraw(x1,y1);
	cpgsci(1);
	}
      cpgscf(pgscf_old);
      cpgsch(pgsch_old);
      if(lmode == 3)
        cpgsci(1);
      }
    cpgsvp(x1v,x2v,y1v,y2v);
    cpgswin(x1w,x2w,y1w,y2w);
    }

  /* botones en modo texto */
  if(modotext_butt)
    {
    printf("WARNING: sorry, text buttons are not yet available!\n");
    }
  return;
}

/*---------------------------------------------------------------------------*/
/* introduce en la matriz xx[4] los valores x1,x2,x3 y x4 (ahorra codigo)    */
void subdata(float xx[],float x1,float x2,float x3,float x4)
{
  xx[0]=x1;
  xx[1]=x2;
  xx[2]=x3;
  xx[3]=x4;
}
