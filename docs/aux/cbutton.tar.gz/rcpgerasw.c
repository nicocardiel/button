/*---------------------------------------------------------------------------*/
/* Version 24-February-1999                                File: rcpgerasw.c */
/*---------------------------------------------------------------------------*/
/* Copyright N. Cardiel & C.E. Garcia, Departamento de Astrofisica           */
/* Universidad Complutense de Madrid, 28040-Madrid, Spain                    */
/* E-mail: ncl@astrax.fis.ucm.es or ceg@astrax.fis.ucm.es                    */
/*---------------------------------------------------------------------------*/
/* This routine is free software; you can redistribute it and/or modify it   */
/* under the terms of the GNU General Public License as published by the Free*/
/* Software Foundation; either version 2 of the License, or (at your option) */
/* any later version. See the file gnu-public-license.txt for details.       */
/*---------------------------------------------------------------------------*/
/*Comment                                                                    */
/*                                                                           */
/* void rcpgerasw(float x1,float x2,float y1,float y2)                       */
/*                                                                           */
/* input: x1,x2,y1,y2                                                        */
/*                                                                           */
/* Clear any rectangle defined by (x1,y1) lower left corner                  */
/*                                (x2,y2) upper right corner                 */
/*                                                                           */
/* float x1 -> x-coordinate of the left hand edge of the rectangle to be     */
/*             cleared, in normalized device coordinates                     */
/* float x2 -> x-coordinate of the right hand edge of the rectangle to be    */
/*             cleared, in normalized device coordinates                     */
/* float y1 -> y-coordinate of the bottom edge of the rectangle to be        */
/*             cleared, in normalized device coordinates                     */
/* float y2 -> x-coordinate of the top edge of the rectangle to be           */
/*             cleared, in normalized device coordinates                     */
/*                                                                           */
/*Comment                                                                    */
/*---------------------------------------------------------------------------*/
#include "cpgplot.h"
#include "cownbutton.h"

void rcpgerasw(float x1,float x2,float y1,float y2)
{
  /* variables locales */
  int ci,fs;
  float x1w,x2w,y1w,y2w;
  float x1v,x2v,y1v,y2v;

  cpgqwin(&x1w,&x2w,&y1w,&y2w);
  cpgqvp(0,&x1v,&x2v,&y1v,&y2v);

  cpgsvp(x1,x2,y1,y2);
  cpgswin(0.0,1.0,0.0,1.0);
  cpgqci(&ci);
  cpgqfs(&fs);
  cpgsci(0);
  cpgsfs(1);
  cpgrect(0.0,1.0,0.0,1.0);
  cpgsci(ci);
  cpgsfs(fs);

  cpgsvp(x1v,x2v,y1v,y2v);
  cpgswin(x1w,x2w,y1w,y2w);
}
